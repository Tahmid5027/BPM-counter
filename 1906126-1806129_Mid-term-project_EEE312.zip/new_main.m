clc; clear all; close all;
%% Load the signal and diclare necessary variables
load('signal1.mat');

Fs = 125; 
window_len = 8 * Fs; 
step_size = 2 * Fs; 


total_windows=148;
window=zeros(total_windows,window_len+1);
for j=1:total_windows
    window(j,:)=sig(1+(j-1)*step_size:1+(j-1)*step_size+window_len);
end

total_windows = floor((length(sig)-window_len)/step_size) + 1;
BPMC = zeros(size(BPM0));
%% Generate the QRS template  

%template-1
% nf=0:10;
% cf = (-10*nf+60).*(nf>=5 & nf<=7) ;%+sqrt(0.25-(nf-3).^2);

%template-2
% nf=1:15;
% cf=0.3*(nf-7).*(nf>=7)+0.3*(nf-8).*(nf>=8)+3.3*(nf-8).*(nf>=8)-3.3*(nf-9).*(nf>=9)-5.5*(nf-9).*(nf>=9)+5.5*(nf-10).*(nf>=10)+2.5*(nf-10).*(nf>=10)-2.5*(nf-11).*(nf>=11);
% plot(nf,cf);

%template-3
t=linspace(0,50,101);
nf=0:0.50:50;
cf=sqrt(0.5625-(nf-1.75).^2).*[t>=1 & t<2.5]+(20*nf-50).*[t>=2.5 & t<=3]+(-20*nf+70).*[t>3 & t<=4]+(20*nf-90).*[t>4 & t<=4.5]+sqrt(0.5625-(nf-5.25).^2).*[t>=4.5 & t<=6];
plot(nf,cf);
%% Main Algorithm

for i=1:total_windows
    START=1; END=window_len;
    curSegment = START+(i-1)*step_size : END+(i-1)*step_size;
    ecg_window=sig(curSegment);
    
    [corr(i,:),lag]=xcorr(cf,ecg_window); % doing cross-correlation
    
    [peak_number,index,peaks]=peak_counter(corr(i,:));
    [bpm_calc,bits]=bpm_counter(peaks,index);
    BPMC(i)=bpm_calc;
    Bits(i)=bits;
end


%% Calculation of Errors
mean_error = mean(abs(BPMC-BPM0))
max_error = max(abs(BPMC-BPM0))
%% Plot the beats per minutes
figure;
plot(BPMC,'b');
hold on, plot(BPM0,'r');
title('Heart Rate Tracking');
xlabel('Window number');
ylabel('Heart Rate (BPM)'); ylim([0, 200]);
legend('Estimated Heart Rate','Ground Truth Heart Rate')





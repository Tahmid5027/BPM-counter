function [BPm,bits] = bpm_counter(peaks,index)
% j=1;
% while j<=1000
%     if(corrected(j)>0)
%         f1=j;
%         j=1001;
%     else
%         j=j+1;
%     end
% end
% k=1000;
% while k>=1
%     if(corrected(k)>0)
%         f2=k;
%         k=0;
%     else
%         k=k-1;
%     end
% end
% distance=f2-f1;
% avg_dis=distance/(peak_count-1);
% Fs=125;
% BPm=60*(Fs/avg_dis);
i=1; bits=0;
index=[index 0 0]; peaks=[peaks 0 0];
while i<=length(index)-2
    if ((peaks(i+1)>peaks(i))&&((peaks(i+1)>peaks(i+2)))&&((peaks(i+1))/max(peaks)>0.4))
        bits=bits+1;
        i=i+1;
    else
        i=i+1;
    end
end
j=1;
while j<=length(index)
    if ((peaks(j+1)>peaks(j))&&((peaks(j+1)>peaks(j+2)))&&((peaks(j+1))/max(peaks)>0.5))
        f1=index(j); break;
    else 
        j=j+1;
    end
end
m=length(index)-2;
while m>=1
    if ((peaks(m+1)>peaks(m))&&((peaks(m+1)>peaks(m+2)))&&((peaks(m+1))/max(peaks)>0.5))
        f2=index(m); break;
    else 
        m=m-1;
    end
end
distance=f2-f1;
avg_dis=distance/(bits-1);
Fs=125;
BPm=60*(Fs/avg_dis);
end
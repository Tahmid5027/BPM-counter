clc; clear all; close all;
%% Load the signal and diclare necessary variables
load('test_signal_B2.mat');

Fs = 125; 
window_len = 8 * Fs; 
step_size = 2 * Fs; 

total_windows=148;
window=zeros(total_windows,window_len+1);
for j=1:total_windows
    window(j,:)=sig(1+(j-1)*step_size:1+(j-1)*step_size+window_len);
end

total_windows = floor((length(sig)-window_len)/step_size) + 1;
BPMC = [];

%% Generate the QRS template  

% Template-1
nf=1:12;
cf = (-3*nf+18).*(nf>=5 & nf<=7);

% Template-2
t=linspace(0,50,101);nf=0:0.50:50;
cf=sqrt(0.5625-(nf-1.75).^2).*[t>=1 & t<2.5]+(20*nf-50).*[t>=2.5 & t<=3]+(-20*nf+70).*[t>3 & t<=4]+(20*nf-90).*[t>4 & t<=4.5]+sqrt(0.5625-(nf-5.25).^2).*[t>=4.5 & t<=6];% Template-1

plot(nf,cf);
%% Main Algorithm

for i=1:total_windows
    START=1; END=window_len;
    curSegment = START+(i-1)*step_size : END+(i-1)*step_size;
    ecg_window=sig(curSegment);
    
    [corr(i,:),lag]=xcorr(cf,ecg_window); % doing cross-correlation
    
    [peak_number,index,peaks]=peak_counter(corr(i,:));
    [bpm_calc,bits]=bpm_counter(peaks,index);
    BPMC(i)=bpm_calc;
end


%% Plot the beats per minutes

figure(2);
plot(BPMC,'b');
title('Heart Rate Tracking');
xlabel('Window number');
ylabel('Heart Rate (BPM)'); ylim([0, 180]);
legend('Estimated Heart Rate')




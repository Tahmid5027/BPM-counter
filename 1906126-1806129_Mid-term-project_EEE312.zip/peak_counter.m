function [p,index,peaks] = peak_counter(corrected)
peak_count=0; j=1; index=zeros(1,100); i=1; peaks=zeros(1,100);
while j<=1000
    if((corrected(j)<corrected(j+1))&&((corrected(j+1)>corrected(j+2))))
        peak_count=peak_count+1;
        index(i)=j+1;
        peaks(i)=corrected(j+1);
        j=j+1;
        i=i+1;
    else
        j=j+1;
    end
end
p=peak_count;
peaks(:,find(index==0))=[];
index(:,find(index==0))=[];
end
